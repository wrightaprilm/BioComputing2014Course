'''
Created on Feb 25, 2014

@author: smirarab

'''

import sys
from alignment import Alignment

import subprocess
    
def filter_alignment(alg, thrs, len_thrs):
    filtered = reduce(set.union, 
                      (set(alg.similar_sequences(x, thrs)) - set([x]) 
                       for x in alg.names()))
    print "%d sequences after filtering by similarity" % len(filtered)
    
    filtered = filter(lambda x:
                      len(alg.sequence(x).replace("-", "")) > len_thrs, 
                      filtered)
    print "%d sequences after filtering by length %d" % (len(filtered), len_thrs)
    
    filtered_alg = Alignment()
    for x in filtered:
        filtered_alg.add_sequence(x, alg.sequence(x))
    
    return filtered_alg


def call_fasttree(input_file):
    subprocess.check_call(["FastTree", "-out", "%s.tree" % input_file, 
            "-nt", "-gtr", 
            input_file])
    
def call_fasttree_and_prune(input_file, subprocess):
    tree_str = subprocess.check_output(["FastTree", "-nt", "-gtr", 
            input_file])
    print tree_str
    from dendropy import Tree
    tree = Tree.get_from_string(tree_str, 'Newick')
    to_rem = tree.get_edge_set(lambda edge:
        False if edge.head_node.label is None or 
        float(edge.head_node.label) > 0.99 else 
        True)
    for edge in to_rem:
        edge.collapse()
    
    print tree.as_newick_string()
    tree.write(open("%s.tre.contracted" % input_file, 'w'), 'Newick')

if __name__ == '__main__':
    in_alg_file = sys.argv[1]
    similarity_threshold = int(sys.argv[2])/100.0
    length_threshold = int(sys.argv[3])
    
    alg = Alignment()
    alg.read_fasta(in_alg_file)
    print "%d sequences were found in alg %s" \
            %(len(alg.names()), in_alg_file)
    
    filtered_alg = filter_alignment\
                    (alg,similarity_threshold, length_threshold)
        
    assert filtered_alg.is_aligned(), "input file is not aligned"
    
    filtered_seq_file = "%s.filtered" %in_alg_file
    filtered_alg.write_fasta(filtered_seq_file, safe_names = True)

    call_fasttree(filtered_seq_file)
        
    call_fasttree_and_prune(filtered_seq_file, subprocess)
    
    