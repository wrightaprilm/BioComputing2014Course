'''
Created on Feb 25, 2014

@author: smirarab
'''
import re

def degap_seq(seq):
    return re.sub(r"[^a-zA-Z]","",seq)
    
class Alignment(object):
    ''' This class represents an alignment '''

    def __init__(self):
        ''' Constructor '''
        self.sequences = dict()
        
    def add_sequence(self, seq_name, seq):
        ''' Adds a sequence to the alignment. 
        Overwrites old sequences with the same name'''
        self.sequences[seq_name] = seq
        
    def names(self):
        ''' return the list of names'''
        return self.sequences.keys()
    
    def sequence(self, k):
        ''' return the sequence for a given name'''
        return self.sequences[k]

    def sequences(self):
        ''' return the list of names'''
        return self.sequences.values()
            
    def read_fasta(self, filename):
        name = None
        seq = []
        for line in open(filename,'rU'):
            if line.startswith(">"):
                if name:
                    self.add_sequence(name, ''.join(seq))
                seq = []
                name = line[1:].strip()
            else:
                seq.append(line.strip())
        self.add_sequence(name, ''.join(seq))

        
    def _safe_name(self, name):
        return name.replace(" ", "_")
    
    def write_fasta(self, dest, safe_names=False):
        ''' Write alignment in fasta format to dest. 
        sequences will be sorted. dest is a File Object.'''
        f = open(dest, 'w') if isinstance(dest, str) else dest
        for name in sorted(self.sequences.keys()):
            f.write('>%s\n%s\n' % 
                       (self.safe_name(name) if safe_names else name,
                        self.sequences[name]))
        if isinstance(dest, str):
            f.close()
            
    def is_aligned(self):
        if len(self.sequences) == 0:
            raise ValueError('empty alignment; full or empty?')
        l = len(self.sequences.values()[0])
        return all( [ len(x) == l for 
                     x in self.sequences.values()] )
        
    def has_gaps(self, key):
        return any ( (x=="-" for x in self.sequences[key]) )
        
    def sequences_without_gaps(self):
        ''' Generates sequences with all gaps removed.
        '''
        for seq in self.sequences.values():
            yield degap_seq(seq)
        
    def max_length(self):
        ''' returns maximum sequence length'''
        return reduce(max,
                      map(len,self.sequences_without_gaps()))
        
    def hamming(self,k1,k2):
        ''' Returns the ratio of sites that 
        are identical. '''
        s1=self.sequences[k1]
        s2=self.sequences[k2]
        l = float(max(len(s1),len(s2)))
        return sum(
                map( lambda x: 1 if x[0]==x[1] else 0,
                   zip(s1,s2) ) ) / l
                   
    def similar_sequences(self, name, similarity_threshold):
        return filter( lambda x: 
                       self.hamming(name, x) >= similarity_threshold,
                       self.sequences.keys() ) 
        
