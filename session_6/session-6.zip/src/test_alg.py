'''
Created on Feb 25, 2014

@author: smirarab
'''
from alignment import Alignment
import sys
import re

''' Show-casing instances of an object'''
a1 = Alignment()
a2 = Alignment()
a1.sequences["Human"]="ACGT"
a2.sequences["Human"]="TGCA"
print a1.sequences["Human"], a2.sequences["Human"]

''' using an object of the type Alignment''' 
alg = Alignment()
alg.add_sequence("Human", "AACGTGATACCTA")
alg.read_fasta("test.fasta")
alg.write_fasta(sys.stdout)
with open("copy_of_test.fasta",'w') as f:
    alg.write_fasta(f)
alg.write_fasta("another_copy.fasta")
print alg.is_aligned()
print alg.has_gaps("Human")
alg.add_sequence("fragment","AAGTG")
print alg.is_aligned()
print alg.has_gaps("fragment")
print alg.max_length()
print alg.hamming("Human","Chimp")
print alg.hamming("Human","Gorila")
print alg.similar_sequences("Human", 0.7)

''' timeit example'''
from timeit import timeit
a=Alignment()
a.add_sequence("s1", 'AC-GT'*1000)
print timeit(lambda: a.has_gaps('s1'), number=10000)

''' regext examples'''
matches = [name for name in alg.names() 
           if re.match(".*GTGA[AT]A.*", alg.sequence(name))]
print matches
motives = re.findall("AA[CG]G[AT][CG]", alg.sequence('Human'))
print motives

